const express = require('express');
const router = express.Router();


const UserModel = require('../models/users');
const TaskModel = require('../models/tasks');
const BadgeModel = require('../models/badges');
router.get('/userById/:userid', (req, res, next) => {
    UserModel.find({ _id: req.params.userid }, (err, records) => {
        if (err) {
            throw err;
        }
        else {
            res.json(records);
        }

    })

});
router.post('/login', (req, res, next) => {
    UserModel.find({ "email": req.body.email }, (err, records) => {
        if (err) {
            res.json("something went wrong");
        }
        else {
            if (records.length > 0) {
                if (records[0].password == req.body.password) {
                    res.json(records[0]);
                }
                else {
                    res.status(400).json("Invalid credentials");
                }
            }
            else {
                res.status(400).json("Invalid credentials");
            }

        }
    });
    

});
router.get('/updatemissedtasks/:userId', (req, res, next) => {
    TaskModel.find({"user":req.params.userId}, (err, records) => {
        if (err) {
            res.status(400).json("Something went wrong!!Please try again after sometime");
        }
        else {
            var tDay = new Date();
            var tDate = tDay.getDate(); var tMonth = tDay.getMonth() + 1; var tYear = tDay.getFullYear();
            var stt = tYear + '-' + tMonth + '-' + tDate;
            var today = new Date(stt);
            for (let i = 0; i < records.length; i++) {
                
                
                if (records[i].due_date < today && records[i].status != "Completed") {
                    
                    TaskModel.update({ _id: records[i]._id }, { $set: { status: 'Missed' } }, () => { })
                }
                else {
                    continue;
                }
            }
            res.json("Updated set of tasks of successfully");
        }

    });

});

router.put('/updateStatus/:taskId', (req, res, next) => {
    TaskModel.update({ _id: req.params.taskId }, { $set: { status: req.body.status } }, (err, success) => {
        if (err) {
            res.status(400).json("Failed  to update!!Please try again after some time..");
        }
        else {
            var thisDay = new Date();
            var thisDae = thisDay.getDate()+1;
           
            var thisMonth = thisDay.getMonth() + 1;
            var thisYear = thisDay.getFullYear();
            var stt = thisYear + '-' + thisMonth + '-' + thisDae;
            var procese = new Date(stt);
           
            TaskModel.update({ $and: [{_id:req.params.taskId}, {status:'Completed'}] }, { $set: {completed_date:thisDay}}, (err, success) => {
                if (err) {
                    res.status(400).json("Something went wrong!!Please try again afer some time")
                }
                else {
                    res.json("Status updated successfully");
                }
            })
            
        }

    });

});
router.get('/badgeInfoByUserId/:userId', (req, res, next) => {
    BadgeModel.find({ "user": req.params.userId }, (err,records) => {
        if (err) {
            res.status(400).json(err);
        }
        else {
            res.json(records[0]);
        }

    });

});
router.get('/taskById/:taskid', (req, res, next) => {
    TaskModel.find({ _id: req.params.taskid }, (err, records) => {
        if (err) {
            throw err;
        }
        else {
            res.json(records);
        }

    })

});
router.get('/activeTasksByUserId/:userId', (req, res, next) => {
    ans_set = [];
    TaskModel.find({"user":req.params.userId}, (err, records) => {
        if (err) {
            res.status(400).send("Something went wrong");
        }
        else {
            var today = new Date();
            var todayMonth = today.getMonth(); var todayYear = today.getFullYear(); var todayDate = today.getDate();
            for (let i = 0; i < records.length; i++) {
                if (records[i].status != "Completed" && (records[i].due_date.getTime()-today.getTime())/(1000*3600*24)>=-1) {
                    ans_set.push(records[i]);
                }
                else {
                    continue;
                }
            }
            ans_set.sort((a, b) => { if (a.due_date < b.due_date) { return -1; } else { return 1; } });
            res.json(ans_set);
            
        }

    });

});
router.get('/totalTasksAdded/:userId', (req, res, next) => {
    TaskModel.find({"user":req.params.userId}, (err, success) => {
        if (err) {
            res.status(400).json("Something went wrong!!Please try after sometime");
        }
        else {
            res.json(success.length);
        }

    });

});
router.get('/missedTasks/:userId', (req, res, next) => {
    TaskModel.find({"user":req.params.userId}, (err, records) => {
        if (err) {
            res.status.json("Something went wrong!!Please try again after sometime");
        }
        else {
            result_set = []

            let thisDay = new Date();
            var dd = thisDay.getDate();
            var mm = thisDay.getMonth()+1 ;
            var yyyy = thisDay.getFullYear();
            var stt = yyyy + '-' + mm + '-' + dd;
            var myDate = new Date(stt); console.log("mydate" + myDate);
            var tod = thisDay.getMonth(); var yea = thisDay.getFullYear();
            for (let i = 0; i < records.length; i++) {
                
                if (records[i].due_date < myDate && records[i].status!="Completed") {
                    result_set.push(records[i]);       
                }
                else {
                    continue;
                }
            }
            res.json(result_set.length);
        }

    });

});
router.get('/deadlineApproaching/:userId', (req, res, next) => {
    thisdate = new Date();
   var  todayMonth=thisdate.getMonth()+1;
    var todayYear = thisdate.getFullYear();
    var todayDate = thisdate.getDate();
    stt = todayYear + '-' + todayMonth + '-' + todayDate;

    var mydate = new Date(stt);
    
    TaskModel.find({"user":req.params.userId}, (err, records) => {
        if (err) {
            res.status(400).json("Something went wrong!!Please try again after sometime");
        }
        else {
            var resultSet=[]
            for (let i = 0; i < records.length; i++) {
                if (records[i].status != "Completed" && Math.ceil((records[i].due_date.getTime() - mydate.getTime()) / (1000 * 3600 * 24)) <= 6 && Math.ceil((records[i].due_date.getTime() - mydate.getTime()) / (1000 * 3600 * 24)>=0)) {
                    resultSet.push(records[i]);
                }
                else {
                    continue;
                }
            }
            res.json(resultSet.length);
        }

    });

});
router.get('/deadlineToday/:userId', (req, res, next) => {
    TaskModel.find({"user":req.params.userId}, (err, records) => {
        if (err) {
            res.status(400).json("Something went wrong");
        }
        else {
            var resultSet = [];
            today = new Date();
            var todayMonth = today.getMonth(); var todayYear = today.getFullYear(); var todayDate = today.getDate();
            for (let i = 0; i < records.length; i++) {
                if (records[i].status != "Completed" && todayMonth == records[i].due_date.getMonth() && todayYear == records[i].due_date.getFullYear() && (records[i].due_date.getDate() == todayDate)) {
                    resultSet.push(records[i]);
                }

            }
            res.json(resultSet.length);
        }
    
})
})

router.get("/completedTaskByUserId/:userId", (req, res, next) => {
    TaskModel.find({ "user": req.params.userId }, (err, records) => {
        if (err) {
            throw res.status(400).json("Something went wrong!!Please try after sometime..");
        }
        else {
            var completedTasks = [];
            for (let i = 0; i < records.length; i++) {
                if (records[i].status == "Completed") {
                    var oneTask = new TaskModel({
                        task_name: records[i].task_name,
                        task_description: records[i].task_description,
                        status: records[i].status,
                        priority: records[i].priority,
                        label: records[i].label,
                        start_date: records[i].start_date,
                        due_date: records[i].due_date,
                        user: records[i].user,
                        completed_date:records[i].completed_date


                    });
                    completedTasks.push(oneTask);
                }
                else {
                    continue;
                }
            }
            
            completedTasks.sort((a, b) => { if (a.due_date > b.due_date) { return -1; } else { return 1; } })
            if (completedTasks.length >= 5) {
                BadgeModel.update({ $and: [{ user: req.params.userId }, { badge_newbie_boolean: false }] }, { $set: { badge_newbie_boolean: true } }, (err, success) => { });
            }
            if (completedTasks.length >= 10) {
                BadgeModel.update({ $and: [{ user: req.params.userId }, { badge_champion_boolean: false }] }, { $set: { badge_champion_boolean: true } }, (err, success) => { });
            }
            BadgeModel.update({ user: req.params.userId }, { $set: { badge_newbie: completedTasks.length } }, (err, success) => { })
            BadgeModel.update({ user: req.params.userId }, { $set: { badge_champion: completedTasks.length } }, (err, success) => { })
            var count_fam = 0; var count_shop = 0; var count_work = 0; var count_ar = 0;
            for (let i = 0; i < completedTasks.length; i++) {
                if (completedTasks[i].label == "Work") {
                    count_work += 1;
                }
                else if (completedTasks[i].label == "Shopping") {
                    count_shop += 1;
                }
                else if (completedTasks[i].label == "Personal") {
                    count_fam += 1;
                }
            }
            
            BadgeModel.update({ "user": req.params.userId }, { $set: { "badge_shopaholic": count_shop } }, (err, success) => { });
            if (count_shop >= 5) {
                
                BadgeModel.update({ $and: [{ "user": req.params.userId }, { badge_shopaholic_boolean: false }] }, { $set: { badge_shopaholic_boolean: true } }, (err, success) => { });
            }

            BadgeModel.update({ "user": req.params.userId }, { $set: { "badge_workaholic": count_work } }, (err, success) => { });
            if (count_work >= 5) {
                BadgeModel.update({ $and: [{ "user": req.params.userId }, { badge_workaholic_boolean: false }] }, { $set: { badge_workaholic_boolean: true } }, (err, success) => { });
            }
            BadgeModel.update({ "user": req.params.userId }, { $set: { "badge_family_guy": count_fam } }, (err, success) => { });
            if (count_fam >= 5) {
                BadgeModel.update({ $and: [{ "user": req.params.userId }, { badge_family_guy_boolean: false }] }, { $set: { badge_family_guy_boolean: true } }, (err, success) => { });
            }
            completedTasks.sort((a, b) => { if (a.completed_date > b.completed_date) { return -1; } else { return 1; } });
            var today = new Date();
            cout_ar = 0;
            thisMonth = today.getMonth();
            thisYear = today.getFullYear();
            for (let iter = 0; iter < completedTasks.length; iter++) {
                if (completedTasks[iter].completed_date.getMonth() == thisMonth && completedTasks[iter].completed_date.getFullYear() == thisYear) {
                    count_ar += 1;
                }
            }
            if (count_ar >= 5) {
                BadgeModel.update({ $and: [{ "user": req.params.userId }, { badge_adrenaline_rush_boolean: false }] }, { $set: { badge_adrenaline_rush_boolean: true } }, (err, success) => { });
            }
            BadgeModel.update({ $and: [{ "user": req.params.userId }, { badge_adrenaline_rush_boolean: false }] }, { $set: { badge_adrenaline_rush: count_ar } }, (err, success) => { });
            res.json(completedTasks);
        }

    });
});
router.get('/numberCompletedTasks/:userId', (req, res, next) => {
    
        TaskModel.find({ "user": req.params.userId, "status": "Completed" }, (err, records) => {
            if (err) {
                res.json(err);
            }
            else {
                res.json(records.length);
            }
        })
    

});
router.get("/taskByUserId/:userId", (req, res, next) => {
    TaskModel.find({ "user": req.params.userId }, (err, records) => {
        if (err) {
            throw res.status(400).json("Something went wrong!!Please try after sometime..");
        }
        else {
            res.json(records);
        }

    });
});
router.get('/users', (req, res, next) => {
    UserModel.find((err, records) => {
        if (err) {
            res.send(err);
        }
        else {
            res.json(records);
        }
    })
});

router.post('/badgePost/:userId', (req, res, next) => {
    var newBadge = new BadgeModel({
        badge_family_guy: 0,
        badge_adrenaline_rush: 0,
        
        badge_shopaholic: 0,
        badge_workaholic: 0,
        badge_newbie: 0,
        badge_champion: 0,
        badge_family_guy_boolean: false,
        badge_adrenaline_rush_boolean: false,
       
        badge_shopaholic_boolean: false,
        badge_workaholic_boolean: false,
        badge_newbie_boolean:false,
        badge_champion_boolean: false,
        user:req.params.userId

    });
    newBadge.save((err, success) => {
        if (err) {
            res.status(400).json(err);
        }
        else {
            res.json("New Badge added successfully");
        }

    });

});
router.post('/userPost', (req, res, next) => {
    var newUser = new UserModel({
        full_name: req.body.full_name,
        email: req.body.email,
        password: req.body.password,
        tasks: req.body.tasks,
        mobile_no:req.body.mobile_no
    });
    UserModel.find({}, (err, records) => {
        if (err) {
            res.status(400).json("Something went wrong!!Please try again after someTime!!");
        }
        else {
            var flagg = 1;
            for (var itera = 0; itera < records.length; itera++) {
                if (records[itera].email == newUser.email) {
                    flagg = 0;
                    break;
                }
            }
            if (flagg == 0) {
                res.status(400).json("That email is taken!!Please use another email..");
            } else {
                var flask = 1;
                for (var faf = 0; faf < records.length; faf++) {
                    if (records[faf].mobile_no == newUser.mobile_no) {
                        flask = 0;
                        break;
                    }
                }
                if (flask == 0) {
                    res.status(400).json("That mobile number is taken!!Please use another mobile number");
                }
                else {
                    newUser.save((err, success) => {
                        if (err) {
                            res.status(400).json(err);
                        }
                        else {
                            res.json(success._id);
                        }
                    });
                }
           
        }
        }

    });

});
router.post('/taskPost', (req, res, next) => {
    var newTask = new TaskModel({
        task_name: req.body.task_name,
        task_description: req.body.task_description,
        status: req.body.status,
        priority:req.body.priority,
        label: req.body.label,
        start_date: req.body.start_date,
        due_date: req.body.due_date,
        user:req.body.user
    });
    newTask.save((err, success) => {
        if (err) {
            res.status(400).json("Something went wrong!!Please try again after sometime..");
        }
        else {
            res.json("New task has been added successfully");
        }
    });

});




module.exports = router;