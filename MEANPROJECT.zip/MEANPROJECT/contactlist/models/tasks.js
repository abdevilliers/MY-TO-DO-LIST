const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const TaskSchema = new Schema({
    task_name: String,
    task_description: String,
    status: String,
    label: String,
    start_date: Date,
    due_date: Date,
    priority: String,
    completed_date:Date,
    user: { type: Schema.Types.ObjectId, ref: "users" }
});
module.exports = mongoose.model("tasks", TaskSchema);
