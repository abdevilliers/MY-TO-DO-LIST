var mongoose = require("mongoose")
const Schema = mongoose.Schema
let UserSchema = new Schema({
    full_name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, minlength: 7, maxlength: 15 },
    mobile_no:{type:Number,required:true,min:1000000000,max:9999999999},
    tasks: [{ type: Schema.Types.ObjectId, ref: "tasks" }],
    badges: {type:Schema.Types.ObjectId,ref:"badges"}
});
module.exports = mongoose.model("users", UserSchema)
