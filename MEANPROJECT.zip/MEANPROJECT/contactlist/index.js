var express = require('express');
var bodyparser = require('body-parser');
var cors = require('cors');
var path = require('path');
const route = require('./routes/route');
const url = 'mongodb://127.0.0.1:27017/hackerearthcompition'

var app = express();
const port = 3000;
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyparser.json());
app.use(cors());
app.use('/api', route);



//testing server
app.get('/', (req, res) => {
    res.send('it is working');

   

});
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/hackathon', (err, client) => {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connected TO THE DATABASE!!");
        var myDay = new Date();
        var myDate = myDay.getDate(); var myMonth = myDay.getMonth() + 1; var myYear = myDay.getFullYear();
        var stt = myYear + '-' + myMonth + '-' + myDate;
        
        var d = new Date();
        

    }
});


app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyparser.json());
app.use('/api', route);
app.use(cors());
app.listen(port, () => {
    console.log("server started at port" + port);


});