import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'appendzero'
})
export class AppendzeroPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    if (parseInt(value) < 10) {
      return '0' + value;
    }
    return value;
  }

}
