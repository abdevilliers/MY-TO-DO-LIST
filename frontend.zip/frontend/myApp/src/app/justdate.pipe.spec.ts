import { JustdatePipe } from './justdate.pipe';

describe('JustdatePipe', () => {
  it('create an instance', () => {
    const pipe = new JustdatePipe();
    expect(pipe).toBeTruthy();
  });
});
