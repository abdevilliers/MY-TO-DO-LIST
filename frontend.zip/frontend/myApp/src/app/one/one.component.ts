import { Component, OnInit,Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { AngularService } from '../angular.service';
import { DueDateValidator } from './DueDateValidator';
import { Router } from '@angular/router';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit {
  taskForm: FormGroup;
  formSubmitted: boolean = false;
  successMessage: string = null;
  errorMessage: string = null;

  constructor(private ngFlashMessageService:NgFlashMessageService,private router:Router,@Inject(LOCAL_STORAGE) private storage: WebStorageService, private formBuilder: FormBuilder,private aService:AngularService) { }

  ngOnInit() {
    this.taskForm = this.formBuilder.group({
      task_name: ['', Validators.required],
      task_description: ['', Validators.required],
      status: ['', []],
      label: ['', Validators.required],
      start_date: ['', []],
      due_date: ['', [Validators.required,DueDateValidator.method]],
      priority: ['', Validators.required],
      user: ['', []]

    });
  }
  formOnSubmit() {
    this.formSubmitted = true;
    
    var todaydate = new Date();
   
    
    var variable = this.taskForm.controls.due_date.value;
    var arr: String[] = this.taskForm.controls.due_date.value.split("-");
    
    
    var result = arr[0] + '-' + arr[1] + '-' + arr[2];
    
    
    this.taskForm.controls.user.setValue(this.storage.get("user")._id);
    
    var newVarr = todaydate.getFullYear() + '-' + todaydate.getMonth() + "-" + todaydate.getDate();
    
    this.taskForm.controls.start_date.setValue(newVarr);
    this.taskForm.controls.status.setValue("New");
    this.aService.postTask(this.taskForm.value).subscribe((success) => {
      this.successMessage = success;
      this.ngFlashMessageService.showFlashMessage({
        messages: [this.successMessage],
        timeout: 3000,
        type:'success'
      })

      ; this.router.navigateByUrl('/one', { skipLocationChange: true }).then(() => {
        this.router.navigate(['/one']);
      });  },
      (error) => { this.errorMessage=error.error})

  }
  backtome() {
    
    this.router.navigateByUrl('/one');
  }
}
