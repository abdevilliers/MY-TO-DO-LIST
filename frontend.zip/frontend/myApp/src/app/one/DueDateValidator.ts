import { AbstractControl } from '@angular/forms';

export class DueDateValidator {
  static method(control: AbstractControl): { noRepeat: true } | null {
    var today = new Date();
    var cur_date = today.getDate();
    var cur_month = today.getMonth()+1;
    var cur_year = today.getFullYear();
    
    
    var received = control.value.split("-");
    var rec_year = parseInt(received[0]);
    var rec_month = parseInt(received[1]);
    var rec_date = parseInt(received[2]);
    
    if (rec_year < cur_year) {
      return { noRepeat: true };
    }
    if (rec_year > cur_year) {
      
      return null;
    }
    if (rec_year == cur_year) {
      if (rec_month < cur_month) {
        
        return { noRepeat: true };
      }
      if (rec_month > cur_month) {
        
        return null;
      }
      if (rec_month == cur_month) {
        if (rec_date > cur_date) {
          
          return null;
        }
        else {
          
            return { noRepeat: true };
          }
        
      }
    }
    
  }
}
