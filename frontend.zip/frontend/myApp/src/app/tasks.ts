export class tasks {
_id:string;
  task_name: string;
  task_description: string;
  status: string;
  label: string;
  priority: string;
  start_date: Date;
  due_date: Date;
  user: string;
  completed_date: Date;
}
