import { ChampionPipe } from './champion.pipe';

describe('ChampionPipe', () => {
  it('create an instance', () => {
    const pipe = new ChampionPipe();
    expect(pipe).toBeTruthy();
  });
});
