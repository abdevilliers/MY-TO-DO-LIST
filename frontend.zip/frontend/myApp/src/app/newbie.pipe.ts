import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'newbie'
})
export class NewbiePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    var stt;
    stt = 5 - parseInt(value);
    return stt;
  }

}
