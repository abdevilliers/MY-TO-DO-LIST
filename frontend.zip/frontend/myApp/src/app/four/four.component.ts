import { Component, OnInit,Inject } from '@angular/core';
import { tasks } from '../tasks';
import { AngularService } from '../angular.service';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { NgFlashMessageService } from 'ng-flash-messages';
import { Router } from '@angular/router';

@Component({
  selector: 'app-four',
  templateUrl: './four.component.html',
  styleUrls: ['./four.component.css']
})
export class FourComponent implements OnInit {
  userTasks: tasks[];
  myTask: tasks;
  errorMessage: string = null;
  listImages: string[] = ['./assets/images/work.jpg', './assets/images/personal.jpg', './assets/images/shopping.jpg', './assets/images/others.jpg'];
  varToSet: boolean = false;
  successMessage: String = null;
  errorMessageOne: string = null;
  errorMessageThree: string = null;
  constructor(private router:Router,private ngFlashMessageService:NgFlashMessageService,private aService: AngularService, @Inject(LOCAL_STORAGE) private storage: WebStorageService) {
    }

  ngOnInit() {
    this.varToSet = false;
    
    this.aService.getActiveTasks(this.storage.get("user")._id).subscribe((success) => {  this.userTasks = success;},
      (error) => { this.errorMessage = error.error;}
    );
    this.ngFlashMessageService.showFlashMessage({
      messages: ["Task status updated successfully!!"],
      type: 'success',
      dismissible: true,
      timeout:false
    });

  }
  showdrop() {
    this.varToSet = true;
  }
  upstat(paramone, param) {
    this.myTask = new tasks();
    var setTasks: tasks[];
    this.myTask.status = param;
    
    this.aService.updatestatus(paramone, this.myTask).subscribe((successOne) => {
      this.successMessage = successOne;
      this.ngFlashMessageService.showFlashMessage({
        messages: ["Task status updated successfully!!"],
        type: 'success',
        timeout:2000
      }); 
      this.aService.completedTasks(this.storage.get("user")._id).subscribe((succcess) => { setTasks = succcess;  this.varToSet = false;},
        (error) => {
          this.errorMessageThree = error.error; this.ngFlashMessageService.showFlashMessage({
            messages: ['Something went wrong.Please try again after some time!!'],
            timeout:5000
          });
        }

      )



    },
     
      (errr) => {this.errorMessageOne=errr.error})
   

  }

}
