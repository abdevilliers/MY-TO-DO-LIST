import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AngularService } from './angular.service';
import { HttpClientModule } from '@angular/common/http';
import { MainpageComponent } from './mainpage/mainpage.component';
import { StorageServiceModule } from 'angular-webstorage-service';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { ThreeComponent } from './three/three.component';
import { FourComponent } from './four/four.component';
import { FiveComponent } from './five/five.component';
import { FirstnamePipe } from './firstname.pipe';
import { ConvertdatePipe } from './convertdate.pipe';
import { AppendzeroPipe } from './appendzero.pipe';
import { AbadgesComponent } from './abadges/abadges.component';
import { SearchtaskComponent } from './searchtask/searchtask.component';
import { ChampionPipe } from './champion.pipe';
import { NewbiePipe } from './newbie.pipe';
import { AdrushPipe } from './adrush.pipe';
import { WorkPipe } from './work.pipe';
import { ShopPipe } from './shop.pipe';
import { FamilyPipe } from './family.pipe';
import { NgFlashMessagesModule } from 'ng-flash-messages';
import { JustdatePipe } from './justdate.pipe';
import { LogoutComponent } from './logout/logout.component';


@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    MainpageComponent,
    OneComponent,
    TwoComponent,
    ThreeComponent,
    FourComponent,
    FiveComponent,
    FirstnamePipe,
    ConvertdatePipe,
    AppendzeroPipe,
    AbadgesComponent,
    SearchtaskComponent,
    ChampionPipe,
    NewbiePipe,
    AdrushPipe,
    WorkPipe,
    ShopPipe,
    FamilyPipe,
    JustdatePipe,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    StorageServiceModule,
    NgFlashMessagesModule.forRoot()
  ],
  providers: [AngularService],
  bootstrap: [AppComponent]
})
export class AppModule { }
