export class badges {
  badge_family_guy: Number;
  badge_adrenaline_rush: Number;

  badge_shopaholic: Number;
  badge_workaholic: Number;
  badge_newbie: Number;
  badge_champion: Number;
  badge_family_guy_boolean: Boolean;
  badge_adrenaline_rush_boolean: Boolean;

  badge_shopaholic_boolean: Boolean;
  badge_workaholic_boolean: Boolean;
  badge_newbie_boolean: Boolean;
  badge_champion_boolean: Boolean;
  user: String
}
