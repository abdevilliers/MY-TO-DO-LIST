import { AppendzeroPipe } from './appendzero.pipe';

describe('AppendzeroPipe', () => {
  it('create an instance', () => {
    const pipe = new AppendzeroPipe();
    expect(pipe).toBeTruthy();
  });
});
