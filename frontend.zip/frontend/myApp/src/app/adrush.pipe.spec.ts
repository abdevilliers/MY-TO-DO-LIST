import { AdrushPipe } from './adrush.pipe';

describe('AdrushPipe', () => {
  it('create an instance', () => {
    const pipe = new AdrushPipe();
    expect(pipe).toBeTruthy();
  });
});
