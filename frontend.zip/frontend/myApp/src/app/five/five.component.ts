import { Component, OnInit, Inject } from '@angular/core';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { AngularService } from '../angular.service';
import { badges } from '../badges';

@Component({
  selector: 'app-five',
  templateUrl: './five.component.html',
  styleUrls: ['./five.component.css']
})
export class FiveComponent implements OnInit {
  fulname: String;
  userBadge: badges;
  errorMessage: String;
  images = [];
  cmpltdtsksno: Number = 0;
  missedtasksno: Number = 0;
  totaltasks: Number = 0;
  deadlineApp: Number = 0;
  deadlineToday: Number = 0;

  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private aService:AngularService) { }

  ngOnInit() {
    this.aService.completedTasksNumber(this.storage.get('user')._id).subscribe((success) => { this.cmpltdtsksno = success; },
      (error) => { this.errorMessage = error.error });
    this.aService.getMissedTasks(this.storage.get("user")._id).subscribe((success) => { this.missedtasksno = success; }, (error) => { this.errorMessage = error.error;})
    this.fulname = this.storage.get("user").full_name;
    this.aService.getTotalTasksAdded(this.storage.get("user")._id).subscribe((success) => { this.totaltasks = success },
      (error) => { this.errorMessage = error.error });
    this.aService.getDeadlineApproachingTasks(this.storage.get("user")._id).subscribe((success) => { this.deadlineApp = success },
      (error) => { this.errorMessage = error.error });
    this.aService.getDeadlineTodayTasks(this.storage.get("user")._id).subscribe((success) => { this.deadlineToday = success },
      (error) => { this.errorMessage = error.error });
    this.aService.completedTasks(this.storage.get("user")._id).subscribe((success) => { }, (error) => { this.errorMessage = error.error });
    this.aService.getBadges(this.storage.get("user")._id).subscribe((success) => {
      this.userBadge = success;
      this.images = [];
      if (this.userBadge.badge_adrenaline_rush_boolean == true) {
        this.images.push('./assets/images/adrenalineRush.jpeg');
      }
      if (this.userBadge.badge_champion_boolean == true) {
        this.images.push('./assets/images/champion.jpg');
      }
      if (this.userBadge.badge_newbie_boolean == true) {
        this.images.push('./assets/images/newbie.png');
      }
      if (this.userBadge.badge_workaholic_boolean == true) {
        this.images.push('./assets/images/work.jpg');
      }
      if (this.userBadge.badge_shopaholic_boolean == true) {
        this.images.push('./assets/images/shopaholic.jpg');
      }
      if (this.userBadge.badge_family_guy_boolean == true) {
        this.images.push('./assets/images/famiycomesfirst.jpg');
      }









    },
      (error) => {this.errorMessage=error.error}

    )

  }

}
