import { WorkPipe } from './work.pipe';

describe('WorkPipe', () => {
  it('create an instance', () => {
    const pipe = new WorkPipe();
    expect(pipe).toBeTruthy();
  });
});
