import { FamilyPipe } from './family.pipe';

describe('FamilyPipe', () => {
  it('create an instance', () => {
    const pipe = new FamilyPipe();
    expect(pipe).toBeTruthy();
  });
});
