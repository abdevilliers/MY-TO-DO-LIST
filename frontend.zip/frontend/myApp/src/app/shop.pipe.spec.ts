import { ShopPipe } from './shop.pipe';

describe('ShopPipe', () => {
  it('create an instance', () => {
    const pipe = new ShopPipe();
    expect(pipe).toBeTruthy();
  });
});
