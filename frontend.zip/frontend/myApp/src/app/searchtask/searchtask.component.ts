import { Component, OnInit, Inject } from '@angular/core';
import { WebStorageService, LOCAL_STORAGE } from 'angular-webstorage-service';
import { AngularService } from '../angular.service';
import { tasks } from '../tasks';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-searchtask',
  templateUrl: './searchtask.component.html',
  styleUrls: ['./searchtask.component.css']
})
export class SearchtaskComponent implements OnInit {
  dict = {};
  myAllTasks : tasks[]=[];
  errorMessage: String = null;
  candidateSet: tasks[];
  answerSet: tasks[];
  show: boolean = false;
  showone: boolean = false;
  showtwo: boolean = false;
  showthree: boolean = false;
  showfour: boolean = false;
  showmess: boolean = false;
  showmessone: boolean = false;
  showmesstwo: boolean = false;
  showmessthree: boolean = false;
  showresults: boolean = false;
  listImages: string[] = ['./assets/images/work.jpg', './assets/images/personal.jpg', './assets/images/shopping.jpg', './assets/images/others.jpg'];
  errorMessageThree: String;
  successMessage: String;
  myTask: tasks;
  errorMessageOne: String;
  varToSet: boolean = false;
  buttonone: boolean = true;
  buttontwo: boolean = true;
  buttonthree: boolean = true;
  buttonfour: boolean = true;
  appfilter: boolean = true;

  constructor(private ngFlashMessageService: NgFlashMessageService,@Inject(LOCAL_STORAGE) private storage: WebStorageService, private aService: AngularService) { }

  ngOnInit() {
  }
  backtome(key, value) {
    this.showresults = false;
    if (key == 'task_name') {
      this.show = true;
      this.appfilter = false;
      if (value != '') {
       

        this.showmess = true;
      }
      
    }
    if (key == 'priority') {
      this.showtwo = true;
      this.buttonone = false;
      if (value != 'temp') {
        this.showmessone = true;
       
      }
    }
    if (key == 'label') {
      this.showthree = true;
      this.buttontwo = false;
      if (value != 'temp') {
        this.showmesstwo = true;
      }
    }
    if (key == 'status') {
      this.buttonthree = false;
      this.showfour = true;
      if (value != 'temp') {
        this.showmessthree = true;
      }
    }
    console.log("back to me");
    
    this.dict[key] = value;
    
    

    

  }
  fronttome(param) {
    this.showresults = false;
    if (param == 'task_name') {
      this.showone = false;
      this.show = false; this.showmess = false; this.appfilter = true;
    }
    if (param == 'priority') {
      this.buttonone = true;
      this.showtwo = false;
      this.showmessone = false;
    }
    if (param == 'label') {
      this.buttontwo = true;
      this.showthree = false;
      this.showmesstwo = false;
    }
    if (param == 'status') {
      this.buttonthree = true;
      this.showfour = false;
      this.showmessthree = false;
    }
    
    for (let key in this.dict) {
      if (key == param) {
        delete this.dict[key];
      }
    }
  }
  backtomeagain() {
    this.answerSet = []; this.candidateSet = [];
    this.aService.getTasksByUserId(this.storage.get("user")._id).subscribe((success) => {
      this.myAllTasks = success;
      var flag: Number = 0;
      for (let i = 0; i < this.myAllTasks.length; i++) {
        {
          for (let key in this.dict) {
            if (key == "task_name") {
              flag = 1;
              if (this.myAllTasks[i]["task_name"].toUpperCase().includes(this.dict["task_name"].toUpperCase())) {
                this.candidateSet.push(this.myAllTasks[i]);
              }
            }
            else {
              continue;
            }
          }
        }
      }
      var flagg: Number;
      if (flag == 0) {
        for (let i = 0; i < this.myAllTasks.length; i++) {
          flagg = 0;
          for (let key in this.dict) {
            if (this.dict[key] != this.myAllTasks[i][key]) {
              flagg = 1; break;
            }
          }
          if (flagg == 0) {
            this.answerSet.push(this.myAllTasks[i]);
          }
        }
        console.log(this.answerSet);
      }
      else {
        
        for (let i = 0; i < this.candidateSet.length; i++) {
          flagg = 0;
          for (let key in this.dict) {
            if (key == "task_name") {
              continue;
            }
            if (this.dict[key] != this.candidateSet[i][key]) {
            
              
              flagg = 1; break;
            }

          }
          if (flagg == 0) {
            this.answerSet.push(this.candidateSet[i]);
          }
        }
        
      }
      
      











    },
      (error) => { this.errorMessage = error.error });
    this.showresults = true;

    
  }
  showdrop() {
    this.varToSet = true;
  }
  upstat(paramone, param) {
    this.myTask = new tasks();
    var setTasks: tasks[];
    this.myTask.status = param;
    
    this.aService.updatestatus(paramone, this.myTask).subscribe((successOne) => {
      this.successMessage = successOne;
      this.ngFlashMessageService.showFlashMessage({
        messages: ['Status has been updated successfully'],
        timeout: 2000,
        type:'success'
      });
      this.aService.completedTasks(this.storage.get("user")._id).subscribe((succcess) => { setTasks = succcess;  this.varToSet = false; },
        (error) => {
          this.errorMessageThree = error.error;
        }

      )



    },

      (errr) => { this.errorMessageOne = errr.error })


  }

}
