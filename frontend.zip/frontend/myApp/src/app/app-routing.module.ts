import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { ThreeComponent } from './three/three.component';
import { FourComponent } from './four/four.component';
import { FiveComponent } from './five/five.component';
import { AbadgesComponent } from './abadges/abadges.component';
import { SearchtaskComponent } from './searchtask/searchtask.component';
import { AppComponent } from './app.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [{ path: 'register', component: RegistrationComponent }, { path: 'login', component: LoginComponent }
  , { path: 'mainPage', component: MainpageComponent },
  {path:'one',component:OneComponent},
  { path: 'two', component: TwoComponent},
  { path: 'three', component: ThreeComponent},
  { path: 'four', component: FourComponent},
  { path: 'five', component: FiveComponent },
  { path: 'abadges', component: AbadgesComponent },
  { path: 'searchtasks', component: SearchtaskComponent },
  
  {path:'logout',component:LogoutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
