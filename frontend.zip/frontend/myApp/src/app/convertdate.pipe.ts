import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'convertdate'
})
export class ConvertdatePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    var mydate = new Date(value);
    var today = new Date();
    
    var ans = Math.ceil((mydate.getTime() - today.getTime()) / (1000 * 3600 * 24));
    return ans;
  }

}
