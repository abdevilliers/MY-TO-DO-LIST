import { NewbiePipe } from './newbie.pipe';

describe('NewbiePipe', () => {
  it('create an instance', () => {
    const pipe = new NewbiePipe();
    expect(pipe).toBeTruthy();
  });
});
