export class Users {
  full_name: string;
  _id: string;
  email: string;
  mobile_no:string
}
