import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'champion'
})
export class ChampionPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    var stt;
    stt = 10 - parseInt(value);
    return stt;
  }

}
