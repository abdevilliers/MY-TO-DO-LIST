import { Component, OnInit ,Inject} from '@angular/core';
import { AngularService } from '../angular.service';
import { tasks } from '../tasks';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';

@Component({
  selector: 'app-two',
  templateUrl: './two.component.html',
  styleUrls: ['./two.component.css']
})
export class TwoComponent implements OnInit {
  myTasks: tasks[];
  errorMessage: string = null;
  listImages: string[] = ['./assets/images/work.jpg', './assets/images/personal.jpg', './assets/images/shopping.jpg', './assets/images/others.jpg'];

  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private aService:AngularService) { }

  ngOnInit() {
    this.aService.completedTasks(this.storage.get("user")._id).subscribe((success) => { this.myTasks = success; },
      (error) => {this.errorMessage=error.error})
    
  }

}
