import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AbadgesComponent } from './abadges.component';

describe('AbadgesComponent', () => {
  let component: AbadgesComponent;
  let fixture: ComponentFixture<AbadgesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AbadgesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbadgesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
