import { Component, OnInit, Inject } from '@angular/core';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { AngularService } from '../angular.service';
import { badges } from '../badges';

@Component({
  selector: 'app-abadges',
  templateUrl: './abadges.component.html',
  styleUrls: ['./abadges.component.css']
})
export class AbadgesComponent implements OnInit {
  myBadge: badges;
  errorMessage: string = null;

  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService, private aService: AngularService) { }

  ngOnInit() {
    this.aService.getBadges(this.storage.get("user")._id).subscribe((success) => {  this.myBadge = success;  },
      (error) => { this.errorMessage = error.error });
  }

}
