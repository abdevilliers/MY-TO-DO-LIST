import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'justdate'
})
export class JustdatePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    
    var date = new Date(value);
    var some = date.getMonth() + 1;
    var stt =  date.getDate()+'-'+some+'-'+date.getFullYear();
    return stt;
  }

}
