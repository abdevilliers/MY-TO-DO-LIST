import { AbstractControl } from '@angular/forms';
import { MethodCall } from '@angular/compiler'
export class PasswordValidator {
  static method(control: AbstractControl): { method: true } | null {
    

    if (control.value.length < 7)
      return { method: true };
    if (control.value.length > 15)
      return { method: true };
    var flag_1 = 0;
    var flag_2 = 0;
    var flag_3 = 0;
    for (let i = 0; i < control.value.length; i++) {
      if (control.value[i].match("[A-Z]")) {
        flag_1 = 1;
      }
      else if (control.value[i].match("[0-9]")) {
        flag_2 = 1;
      }
      else if (control.value[i].match("[!@#$%^&*()-]"))
        flag_3 = 1;
      
    }
    
    if (flag_1 == 1 && flag_2 == 1 && flag_3 == 1)
      return null;
    return { method: true };

    return null;
  }

}
