import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,AbstractControl} from
  '@angular/forms';
import { Router } from '@angular/router';
import { AngularService } from '../angular.service';
import { PasswordValidator } from './PasswordValidator';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { NgFlashMessageService } from 'ng-flash-messages';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm: FormGroup;
  formSubmitted: boolean = false;
  errorMessage: string = null;
  successMessage: string = null;
  newVar: boolean = false;
  errorMessageTwo: String;
  successMessagetwo: String;
  flag_one: boolean = false;
  flag_two: boolean = false;
  flag_three: boolean = false;
  flag_four: boolean = false;

  constructor(private ngFlashMessageService: NgFlashMessageService, @Inject(LOCAL_STORAGE) private storage: WebStorageService, private formBuilder: FormBuilder, private router: Router, private regService: AngularService) {  }

  ngOnInit() {
    

    this.ngFlashMessageService.showFlashMessage({
      messages: ['hey it works']
    });
    this.registrationForm = this.formBuilder.group({
      full_name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(7), Validators.maxLength(15), PasswordValidator.method]],
      confirm_password: ['', [Validators.required]],
      mobile_no: ['', [Validators.min(1000000000), Validators.max(9999999999)]]

    });
  }
  form_submitted() {
    this.regService.registerNewUser(this.registrationForm.value).subscribe((param) => {
      this.successMessage = param; this.regService.badgePost(this.successMessage).subscribe((successone) => { this.successMessagetwo = successone; },
        (errr) => { this.errorMessageTwo = errr.error });
      this.router.navigateByUrl('/login');
    },
      (error) => { this.formSubmitted = true; this.errorMessage = error.error;  }
    );


  }
  navigateToLogin() {
    
    this.router.navigate(['/login']);
  }
  verifyConfirmPassword(param) {
    
    
    if (param == this.registrationForm.controls.password.value) {
      
      this.newVar = true;
    }
    else
      this.newVar = false;



  }
  showFlash() {
    // 1st parameter is a flash message text
    // 2nd parameter is optional. You can pass object with options.
    this.ngFlashMessageService.showFlashMessage({
      messages: ['hey it works'],
      type: 'success'
    });
  }
  thisfunc(param) {
    
    this.flag_one = false;
    this.flag_two = false;
    this.flag_three = false;
    this.flag_four = false;
    if (param.length >= 7 && param.length <= 15) {
      this.flag_four = true;
    }
    for (let i = 0; i < param.length; i++) {
      
      if (param[i].match("[!@#$%^&*()-]")) {
        
        
        this.flag_one = true;


      }
      else if (param[i].match("[A-Z]")) {
        
        this.flag_two = true;
      }
      else if (param[i].match("[0-9]")) {
        
        this.flag_three = true;
      }

    }
    


  }
}
