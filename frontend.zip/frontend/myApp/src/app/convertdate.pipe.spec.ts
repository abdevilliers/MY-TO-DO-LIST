import { ConvertdatePipe } from './convertdate.pipe';

describe('ConvertdatePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertdatePipe();
    expect(pipe).toBeTruthy();
  });
});
