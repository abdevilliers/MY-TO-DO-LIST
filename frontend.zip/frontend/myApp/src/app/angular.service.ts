import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tasks } from './tasks';
import { badges } from './badges';

@Injectable({
  providedIn: 'root'
})
export class AngularService {

  constructor(private http: HttpClient) { }
  registerNewUser(param): Observable<string> {
    return this.http.post<string>("http://localhost:3000/api/userPost", param);
  }
  loginFn(param): Observable<string> {
    return this.http.post<string>("http://localhost:3000/api/login", param);
  }
  postTask(param): Observable<string> {
    return this.http.post<string>("http://localhost:3000/api/taskPost", param);
  }
  getTasksByUserId(param):Observable<tasks[]> {
    var url = "http://localhost:3000/api/taskByUserId/" + param;
    return this.http.get<tasks[]>(url);

  }
  getBadges(param): Observable<badges> {
    var url = "http://localhost:3000/api/badgeInfoByUserId/" + param;
    return this.http.get<badges>(url);
  }
  getActiveTasks(param): Observable<tasks[]> {
    var url = "http://localhost:3000/api/activeTasksByUserId/" + param;
    return this.http.get<tasks[]>(url);
  }
  getTotalTasksAdded(param): Observable<Number>
{
    var url = "http://localhost:3000/api/totalTasksAdded/" + param;

    return this.http.get<Number>(url);
  }
  getMissedTasks(param): Observable<Number> {
    var url = "http://localhost:3000/api/missedTasks/" + param;
    return this.http.get<Number>(url);
  }
  getDeadlineApproachingTasks(param): Observable<Number> {
    var url = "http://localhost:3000/api/deadlineApproaching/" + param;
    return this.http.get<Number>(url);
  }
  getDeadlineTodayTasks(param): Observable<Number> {
    var url = "http://localhost:3000/api/deadlineToday/" + param;
    return this.http.get<Number>(url);
  }
  completedTasks(param): Observable<tasks[]> {
    var url = "http://localhost:3000/api/completedTaskByUserId/" + param;
    return this.http.get<tasks[]>(url);
  }
  completedTasksNumber(param): Observable<Number> {
    var url = "http://localhost:3000/api/numberCompletedTasks/" + param;
    return this.http.get<Number>(url);
  }
  updatestatus(param,taskObj): Observable<String> {
    var url = "http://localhost:3000/api/updateStatus/" + param;
    return this.http.put<String>(url, taskObj);
    
  }
  badgePost(param): Observable<String> {
    var url = "http://localhost:3000/api/badgePost/" + param;
    var b: badges;
    
    return this.http.post<String>(url, b);
    
  }
  updatemissedtasks(param): Observable<String> {
    var url = "http://localhost:3000/api/updatemissedtasks/" + param;
    return this.http.get<String>(url);
  }


}
