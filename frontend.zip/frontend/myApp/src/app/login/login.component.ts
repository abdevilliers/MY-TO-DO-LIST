import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AngularService } from '../angular.service';
import { Router } from '@angular/router';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { NgFlashMessageService } from 'ng-flash-messages';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMessage: string = null;
  formSubmitted: boolean = null;
  dummy: String = null;
  errorOne: String = null;
  somevar: boolean = true;

  constructor(private ngFlashMessageService: NgFlashMessageService, @Inject(LOCAL_STORAGE) private storage: WebStorageService, private formBuilder: FormBuilder, private myService: AngularService, private router: Router) {
    this.ngFlashMessageService.showFlashMessage({
      messages: ['Registration successful'],
      timeout: 2000,
      type:'success'
    })

  }

  ngOnInit() {
    
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
    
  }
  form_submitted(param) {
    
    this.myService.loginFn(this.loginForm.value).subscribe(
      (success) => {
        this.ngFlashMessageService.showFlashMessage({
          messages: ['Registration successful'],
          timeout: 2000,
          type: 'success'
        });
         this.storage.set("user", success); this.myService.updatemissedtasks(this.storage.get("user")._id).subscribe((success) => {this.dummy=success }, (error) => {this.errorOne=error.error });
        this.router.navigateByUrl('/mainPage');
      }, (error) => { console.log(error); this.formSubmitted = true; this.errorMessage = error.error; }
    );
  }
  display() {
    this.ngFlashMessageService.showFlashMessage({
      messages: ['Registration successful'],
      timeout: 2000,
      type: 'success'
    });
    this.somevar = false;
  }


}
